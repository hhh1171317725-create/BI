function extensionFor(url) {
  const match = new URL(url).pathname.match(/\.(jpe?g|png|webp|avif)(?:$|\.)/i);
  return (match?.[1] || "jpg").toLowerCase().replace("jpeg", "jpg");
}

function todayFolder(now = new Date()) {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

const pendingNames = new Map();

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const key = pendingNames.has(item.finalUrl) ? item.finalUrl : item.url;
  const queue = pendingNames.get(key);
  if (!queue?.length) return;
  const filename = queue.shift();
  if (!queue.length) pendingNames.delete(key);
  suggest({ filename, conflictAction: "overwrite" });
});

async function downloadImages(sku, urls) {
  const folder = todayFolder();
  const results = await Promise.allSettled(urls.map((url, index) => {
    const filename = `jd-images/${folder}/${sku}-${String(index + 1).padStart(2, "0")}.${extensionFor(url)}`;
    const queue = pendingNames.get(url) || [];
    queue.push(filename);
    pendingNames.set(url, queue);
    return chrome.downloads.download({
      url,
      filename,
      conflictAction: "overwrite",
      saveAs: false
    });
  }));
  return results.filter((result) => result.status === "fulfilled").length;
}

async function waitForTab(tabId, timeoutMs = 30000) {
  const current = await chrome.tabs.get(tabId);
  if (current.status === "complete") return;
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("商品页加载超时"));
    }, timeoutMs);
    const listener = (updatedId, changeInfo) => {
      if (updatedId !== tabId || changeInfo.status !== "complete") return;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function collectFromTab(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, { type: "collectImages" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return chrome.tabs.sendMessage(tabId, { type: "collectImages" });
  }
}

async function notifyProgress(payload) {
  try {
    await chrome.runtime.sendMessage({ type: "batchProgress", ...payload });
  } catch {
    // The popup may be closed while the background task continues.
  }
}

async function batchDownload(skus, progress = notifyProgress) {
  const results = [];
  for (const [position, sku] of skus.entries()) {
    await progress({ position: position + 1, total: skus.length, sku, state: "loading" });
    let tab;
    try {
      tab = await chrome.tabs.create({ url: `https://item.jd.com/${sku}.html`, active: false });
      await waitForTab(tab.id);
      await new Promise((resolve) => setTimeout(resolve, 2500));
      const found = await collectFromTab(tab.id);
      if (!found?.matchedElements) throw new Error("没有找到图片轮播区域");
      if (!found.urls.length) throw new Error("轮播区域没有图片");
      const completed = await downloadImages(sku, found.urls);
      results.push({ sku, success: completed > 0, images: completed, error: completed ? "" : "下载失败" });
    } catch (error) {
      results.push({ sku, success: false, images: 0, error: error.message || "处理失败" });
    } finally {
      if (tab?.id) await chrome.tabs.remove(tab.id).catch(() => {});
    }
    await progress({ position: position + 1, total: skus.length, sku, state: "complete" });
    if (position < skus.length - 1) await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  return results;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "downloadImages") {
    downloadImages(message.sku, message.urls).then((completed) => {
      sendResponse({ completed, total: message.urls.length });
    });
    return true;
  }
  if (message?.type === "batchDownload") {
    if (message.bridge) {
      let trusted = false;
      try {
        trusted = ["huanghaha.fun", "www.huanghaha.fun"].includes(new URL(_sender.url).hostname);
      } catch {}
      if (!trusted) {
        sendResponse({ error: "网页来源未授权" });
        return false;
      }
    }
    const progress = message.bridge && _sender.tab?.id
      ? (payload) => chrome.tabs.sendMessage(_sender.tab.id, { type: "batchProgress", ...payload }).catch(() => {})
      : notifyProgress;
    batchDownload(message.skus, progress)
      .then((results) => sendResponse({ results }))
      .catch((error) => sendResponse({ error: error.message || "批量任务失败" }));
    return true;
  }
  return false;
});
